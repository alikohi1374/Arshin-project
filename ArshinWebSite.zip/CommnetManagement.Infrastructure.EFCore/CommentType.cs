﻿namespace CommnetManagement.Infrastructure.EFCore
{
    public static class CommentType
    {
        public const int Product = 1;
        public const int Article = 2;
    }
}
