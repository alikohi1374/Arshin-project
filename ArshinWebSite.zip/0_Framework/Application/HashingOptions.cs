﻿namespace _0_Framework.Application
{
    public sealed class HashingOptions
    {
        public int Iterations { get; set; } = 10000;
    }
}