﻿using System.Collections.Generic;
using _0_Framework.Application;
using ShopManagement.Application.Contracts.ProductCategory;
using ShopManagement.Domain.ProductCategoryAgg;

namespace ShopManagement.Application
{
    public class ProductCategoryApplication: IProductCategoryApplication
    {
        private readonly IFileUploader _fileUploader;
        private readonly IProductCategoryRepository _productCategoryRepository;

        public ProductCategoryApplication(IProductCategoryRepository productCategoryRepository, IFileUploader fileUploader)
        {
            _productCategoryRepository = productCategoryRepository;
            _fileUploader = fileUploader;
        }

        public OperationResult Create(CreateProductCategory command)
        {
            var Operation = new OperationResult();
            if (_productCategoryRepository.Exist(x=>x.Name==command.Name))
                return Operation.Failed(ApplicationMessages.DuplicatedRecord );
            var slug = command.Slug.Slugify();
            var picturePath = $"{command.Slug}";
            var filename = _fileUploader.Upload(command.Picture, picturePath);
            var productcategory =new ProductCategory(command.Name,command.Description,filename
           , command.Description,command.PictureAlt,command.Keywords,command.PictureTitle, slug);
             _productCategoryRepository.Create( productcategory);
             _productCategoryRepository.Save();

             return Operation.Succeeded("");
        }

        public OperationResult Edit(EditProductCategory command)
        {
            var Operation = new OperationResult();
            var productCategory = _productCategoryRepository.Get(command.Id);
            if (productCategory == null)
                return Operation.Failed(ApplicationMessages.RecordNotFound);

            if (_productCategoryRepository.Exist(x => x.Name == command.Name && x.Id != command.Id))
                return Operation.Failed(ApplicationMessages.DuplicatedRecord);

            var slug = command.Slug.Slugify();
            var picturePath = $"{command.Slug}";
            var filename = _fileUploader.Upload(command.Picture, picturePath);
            productCategory.Edit(command.Name,command.Description,filename,command.PictureAlt,command.PictureTitle,command.Keywords,command.MetaDescription,slug);
            _productCategoryRepository.Save();
            return Operation.Succeeded();
        }

        public EditProductCategory GetDetails(long id)
        {
            return _productCategoryRepository.GetDetails(id);
        }

        public List<ProductCategoryViewModel> Search(ProductCategorySearchModel searchModel)
        {
            return _productCategoryRepository.Search(searchModel);
        }

        public List<ProductCategoryViewModel> GetProductCategories()
        {
            return _productCategoryRepository.GetCategories();
        }
    }
}
