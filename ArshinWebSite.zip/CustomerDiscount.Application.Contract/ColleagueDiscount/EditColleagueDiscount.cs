﻿namespace DiscountManagement.Application.Contract.ColleagueDiscount
{
    public class EditColleagueDiscount : DefineColleagueDiscount
    {
        public long Id { get; set; }
    }
}