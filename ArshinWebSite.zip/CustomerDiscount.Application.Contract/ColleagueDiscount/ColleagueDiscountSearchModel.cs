﻿namespace DiscountManagement.Application.Contract.ColleagueDiscount
{
    public class ColleagueDiscountSearchModel
    {
        public long ProductId { get; set; }
    }
}