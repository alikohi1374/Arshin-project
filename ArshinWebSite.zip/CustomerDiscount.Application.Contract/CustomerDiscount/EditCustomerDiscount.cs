﻿namespace DiscountManagement.Application.Contract.CustomerDiscount
{
    public class EditCustomerDiscount : DefineCustomerDiscount
    {
        public long Id { get; set; }
    }
}