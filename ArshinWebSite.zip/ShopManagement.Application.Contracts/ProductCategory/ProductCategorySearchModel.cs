﻿namespace ShopManagement.Application.Contracts.ProductCategory
{
    public class ProductCategorySearchModel
    {
        public string Name { get; set; }
    }
}