﻿namespace ShopManagement.Application.Contracts.ProductPicture
{
    public class EditProductPicture:CreateProductPicture
    {
        public long Id { get; set; }
    }
}