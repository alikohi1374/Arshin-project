﻿using System;
using System.Collections.Generic;
using System.Linq;
using _01_ArshinQuery.Contracts.Product;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Nancy.Json;
using ShopManagement.Application.Contracts.Order;

namespace ServiceHost.Pages
{
    public class CartModel : PageModel
    {
        public List<CartItem> CartItems;
        public const string CookieName = "cart-items";
        private readonly IProductQuery _productQuery;

        public CartModel(IProductQuery productQuery)
        {
            CartItems = new List<CartItem>();
            _productQuery = productQuery;
        }

        public void OnGet()
        {
            var serializer = new JavaScriptSerializer();
            var value = Request.Cookies[CookieName];
            var cartItems = serializer.Deserialize<List<CartItem>>(value);
            foreach (var item in cartItems)
                item.CalculateTotalItemPrice();

            CartItems = _productQuery.CheckInventoryStatus(cartItems);
        }

        public IActionResult OnGetRemoveFromCart(long id, decimal count)
        {
            var serializer = new JavaScriptSerializer();
            var value = Request.Cookies[CookieName];
            var cartItems = new List<CartItem>();

            if (!string.IsNullOrWhiteSpace(value))
            {
                try { cartItems = serializer.Deserialize<List<CartItem>>(value); }
                catch { cartItems = new List<CartItem>(); }
            }

            var itemToRemove = cartItems
                .FirstOrDefault(x => x.Id == id && Math.Abs(x.Count - count) < 0.001M);

            if (itemToRemove != null)
                cartItems.Remove(itemToRemove);

            Response.Cookies.Append(CookieName, serializer.Serialize(cartItems),
                new CookieOptions { Expires = DateTime.Now.AddDays(2), Path = "/" });

            // ✅ بلافاصله کوکی جدید را بازخوانی کن و صفحه را برگردان
            CartItems = cartItems;
            foreach (var i in CartItems)
                i.CalculateTotalItemPrice();

            return Page(); // بدون Redirect
        }

    }
}
