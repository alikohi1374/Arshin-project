﻿const cookieName = "cart-items";

function showCartMessage() {
    const box = document.getElementById("cartMessage");
    const progress = document.getElementById("cartMessageProgress");
    const closeBtn = document.getElementById("cartMessageClose");
    const duration = 5000; // دقیقا 10 ثانیه
    let timerID;

    if (!box || !progress) {
        console.error("Cart message element not found in DOM!");
        return;
    }

    // ابتدا نمایش اولیه
    box.style.display = "block";
    box.style.opacity = "1";
    box.style.animation = "bounceDown 0.6s ease forwards";

    // ریست نوار زمان
    progress.style.transition = "none";
    progress.style.width = "0%";

    // شروع پر شدن بعد از یک فریم
    requestAnimationFrame(() => {
        progress.style.transition = `width ${duration}ms linear`;
        progress.style.width = "100%";
    });

    // خروج بعد از مدت زمان مشخص
    timerID = setTimeout(() => hideCartMessage(), duration);

    // خروج با ضربدر
    closeBtn.onclick = () => {
        clearTimeout(timerID);
        hideCartMessage();
    };

    function hideCartMessage() {
        box.style.animation = "fadeOut 0.5s ease forwards";
        setTimeout(() => {
            box.style.display = "none";
            progress.style.width = "0%";
        }, 500);
    }
}
    // افزودن به سبد خرید
function addToCart(id, name, price, picture) {
    // پاکسازی رشته قیمت مثلاً "38.000 تومان" → 38000
    const numericPrice = parseInt(String(price).replace(/[^0-9]/g, ""));

    let products = $.cookie("cart-items");
    products = products ? JSON.parse(products) : [];

    const count = $("#productCount").val();
    products.push({
        id,
        name,
        unitPrice: numericPrice,
        picture,
        count,
        isInStock: true,
        discountRate: 0,
        discountAmount: 0,
        itemPayAmount: numericPrice
    });


    $.cookie("cart-items", JSON.stringify(products), { expires: 2, path: "/" });
    updateCart();
    showCartMessage();
}


    // بروزرسانی سبد خرید و جمع کل
function updateCart() {
    let products = $.cookie(cookieName);
    if (!products) {
        $("#cart_item_count").text(0);
        $(".shopping-cart-total span").text("0 تومان");
        return;
    }
    products = JSON.parse(products);

    let totalCount = 0;
    let totalAmount = 0;

    products.forEach(p => {
        let priceClean = p.unitPrice.toString().replace(/,/g, '').replace(/\./g, '');
        let priceNumber = parseFloat(priceClean);
        let countNumber = parseFloat(p.count);

        totalCount += countNumber;
        totalAmount += priceNumber * countNumber;
    });

    // تعداد کل
    $("#cart_item_count").text(totalCount);
    // جمع کل مبلغ با جداکننده هزارگان
    $(".shopping-cart-total span").text(totalAmount.toLocaleString() + " تومان");

    // ساخت لیست آیتم‌ها
    const cartItemsWrapper = $("#cart_items_wrapper");
    cartItemsWrapper.html('');
    products.forEach((x, idx) => {
        const html = `
        <li class="cart-item" style="padding:10px 0; border-bottom:1px solid #ddd;">
            <div class="shopping-cart-img" style="display:inline-block; vertical-align:top;">
                <img src="/ProductPictures/${x.picture}" alt="${x.name}" style="width:60px; height:auto; border-radius:5px;">
            </div>
            <div class="shopping-cart-title" style="display:inline-block; margin-right:10px; vertical-align:top;">
                <h6 style="margin:0;">${x.name}</h6>
                <h6 style="margin:0; font-size:14px; color:#666;">قیمت: ${x.unitPrice} تومان</h6>
                <p style="margin:0; font-size:13px;">متراژ: ${x.count}</p>
            </div>
            <div class="shopping-cart-delete" style="display:inline-block; float:left;">
                <a onclick="removeFromCart(${idx})" style="color:red; cursor:pointer;">
                    <i class="fi-rs-cross-small"></i>
                </a>
            </div>
        </li>`;
        cartItemsWrapper.append(html);
    });
}


function removeFromCart(index) {
    let products = $.cookie(cookieName);
    if (!products) return;
    products = JSON.parse(products);

    // پیدا کردن آیتم بر اساس اندیس
    const item = products[index];
    if (!item) return;

    // فراخوانی هندلر بک‌اند
    const url = `/Cart?handler=RemoveFromCart&id=${item.id}&count=${item.count}`;
    fetch(url)
        .then(res => res.text())
        .then(() => {
            // حذف از فرانت و بروزرسانی فوری نیز
            products.splice(index, 1);
            $.cookie(cookieName, JSON.stringify(products), { expires: 2, path: "/" });
            updateCart();
        })
        .catch(err => console.error("remove error:", err));
}


function changeCartItemCount(id, totalId, count) {
    var products = $.cookie(cookieName);
    products = JSON.parse(products);
    const productIndex = products.findIndex(x => x.id == id);
    products[productIndex].count = count;
    const product = products[productIndex];
    const newPrice = parseInt(product.unitPrice) * parseInt(count);
    $(`#${totalId}`).text(newPrice);
    //products[productIndex].totalPrice = newPrice;
    $.cookie(cookieName, JSON.stringify(products), { expires: 2, path: "/" });
    updateCart();

    //const data = {
    //    'productId': parseInt(id),
    //    'count': parseInt(count)
    //};

    //$.ajax({
    //    url: url,
    //    type: "post",
    //    data: JSON.stringify(data),
    //    contentType: "application/json",
    //    dataType: "json",
    //    success: function (data) {
    //        if (data.isInStock == false) {
    //            const warningsDiv = $('#productStockWarnings');
    //            if ($(`#${id}-${colorId}`).length == 0) {
    //                warningsDiv.append(`<div class="alert alert-warning" id="${id}-${colorId}">
    //                    <i class="fa fa-exclamation-triangle"></i>
    //                    <span>
    //                        <strong>${data.productName} - ${color
    //                    } </strong> در حال حاضر در انبار موجود نیست. <strong>${data.supplyDays
    //                    } روز</strong> زمان برای تامین آن نیاز است. ادامه مراحل به منزله تایید این زمان است.
    //                    </span>
    //                </div>
    //                `);
    //            }
    //        } else {
    //            if ($(`#${id}-${colorId}`).length > 0) {
    //                $(`#${id}-${colorId}`).remove();
    //            }
    //        }
    //    },
    //    error: function (data) {
    //        alert("خطایی رخ داده است. لطفا با مدیر سیستم تماس بگیرید.");
    //    }
    //});


    const settings = {
        "url": "https://localhost:5001/api/inventory",
        "method": "POST",
        "timeout": 0,
        "headers": {
            "Content-Type": "application/json"
        },
        "data": JSON.stringify({ "productId": id, "count": count })
    };

    $.ajax(settings).done(function (data) {
        if (data.isStock == false) {
            const warningsDiv = $('#productStockWarnings');
            if ($(`#${id}`).length == 0) {
                warningsDiv.append(`
                    <div class="alert alert-warning" id="${id}">
                        <i class="fa fa-warning"></i> کالای
                        <strong>${data.productName}</strong>
                        در انبار کمتر از تعداد درخواستی موجود است.
                    </div>
                `);
            }
        } else {
            if ($(`#${id}`).length > 0) {
                $(`#${id}`).remove();
            }
        }
    });
}